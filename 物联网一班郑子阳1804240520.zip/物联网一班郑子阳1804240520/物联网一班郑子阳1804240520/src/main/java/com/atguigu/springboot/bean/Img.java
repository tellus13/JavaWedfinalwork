package com.atguigu.springboot.bean;

public class Img {
    public String img;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
