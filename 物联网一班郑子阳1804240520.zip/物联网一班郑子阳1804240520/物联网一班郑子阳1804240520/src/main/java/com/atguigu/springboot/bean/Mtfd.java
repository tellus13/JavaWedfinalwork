package com.atguigu.springboot.bean;

public class Mtfd {
    public String shuju;

    public String getShuju() {
        return shuju;
    }

    public void setShuju(String shuju) {
        this.shuju = shuju;
    }
}
