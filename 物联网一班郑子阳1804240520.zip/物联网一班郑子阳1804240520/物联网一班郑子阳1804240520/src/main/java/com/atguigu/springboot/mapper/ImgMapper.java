package com.atguigu.springboot.mapper;

import com.atguigu.springboot.bean.Img;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ImgMapper extends BaseMapper<Img> {

}
