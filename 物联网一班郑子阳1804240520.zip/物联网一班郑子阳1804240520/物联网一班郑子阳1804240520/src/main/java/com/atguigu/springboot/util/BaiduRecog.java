package com.atguigu.springboot.util;

public class BaiduRecog {

}
