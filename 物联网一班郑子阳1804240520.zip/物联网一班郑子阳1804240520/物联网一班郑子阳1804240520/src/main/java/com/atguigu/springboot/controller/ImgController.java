package com.atguigu.springboot.controller;

import com.atguigu.springboot.bean.Img;
import com.atguigu.springboot.bean.Mtfd;
import com.atguigu.springboot.mapper.ImgMapper;
import com.atguigu.springboot.mapper.MtfdMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ImgController {
    @Autowired
    ImgMapper imgMapper;

    @RequestMapping("/img")
    @ResponseBody
    public List<Img> sslectMtfd()
    {
        List<Img>imgList=new ArrayList<Img>();
        imgList=imgMapper.selectList(new QueryWrapper<>());
        return imgList;
    }
}




