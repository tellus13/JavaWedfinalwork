package com.atguigu.springboot.bean;

public class Xsdt {
    public String shuju;

    public String getShuju() {
        return shuju;
    }

    public void setShuju(String shuju) {
        this.shuju = shuju;
    }

    @Override
    public String toString() {
        return "Xsdt{" +
                "shuju='" + shuju + '\'' +
                '}';
    }
}
