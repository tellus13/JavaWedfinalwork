package com.atguigu.springboot.util;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Service
public class Myself_util {



    // 用符号分隔进行添加
   public String   addwithsymbol(Object object1,Object object2, String symbol){
       if (object1==""||object1 == null){
           String object  = "".toString();
           String result = object+object2;
           return result;
       }
       String object  = object1.toString();
       String result = object+symbol+object2;
       return result;

    }

    //把用符号分隔的字符串进行拆分
    public List<String> StringtoElement(String object1){
       List<String> objectList = new ArrayList<String>();

        if(object1.indexOf("_;")!=-1) {
            String[] strArr = object1.split("_;");
            // 把数组转未集合
            objectList = Arrays.asList(strArr);
            return objectList;
        }

        objectList.add(object1);
       return objectList;

    }

    //把String转为Float
    public float StringtoFloat(String s1){

        String s = s1;
        BigDecimal temp = BigDecimal.valueOf(Double.valueOf(s));
// 将temp乘以100
        temp = temp.multiply(BigDecimal.valueOf(100));
        float sum = temp.intValue();
        System.out.println(sum/100);
        float  end = sum/100;
       return end;
    }

}
