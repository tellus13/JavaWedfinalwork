package com.atguigu.springboot.controller;

import com.atguigu.springboot.bean.Mtfd;
import com.atguigu.springboot.mapper.MtfdMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@Controller
public class MtfdController {
    @Autowired
    MtfdMapper mtfdMapper;

    @RequestMapping("/mtfd1")
    @ResponseBody
    public List<Mtfd> sslectMtfd()
    {
        List<Mtfd>mtfdList=new ArrayList<Mtfd>();
        mtfdList=mtfdMapper.selectList(new QueryWrapper<>());
        return mtfdList;
    }
}
