package com.atguigu.springboot.bean;

public class Tzgg {

    public String shuju;

    public String getShuju() {
        return shuju;
    }

    public void setShuju(String shuju) {
        this.shuju = shuju;
    }
}
