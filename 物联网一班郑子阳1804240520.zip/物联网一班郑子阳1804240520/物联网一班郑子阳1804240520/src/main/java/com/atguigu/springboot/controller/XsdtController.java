package com.atguigu.springboot.controller;

import com.atguigu.springboot.bean.Mtfd;
import com.atguigu.springboot.bean.Xsdt;
import com.atguigu.springboot.mapper.XsdtMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import java.util.ArrayList;
import java.util.List;


@Controller
public class XsdtController {
    @Autowired
    XsdtMapper xsdtMapper;

    @RequestMapping("/xsdt1")
    @ResponseBody
    public List<Xsdt> sslectMtfd()
    {
        List<Xsdt> xsdtList = new ArrayList<Xsdt>();
        xsdtList = xsdtMapper.selectList(new QueryWrapper<>());
        System.out.println(xsdtList);
        return xsdtList;
    }

    @GetMapping("/xsdt2")
    public Xsdt sslectMtfd2()
    {
        Xsdt xsdt=new Xsdt();
        xsdt=xsdtMapper.selectOne(new QueryWrapper<>());
        System.out.println("xxdxx");
        return xsdt;
    }

}
