package com.atguigu.springboot.mapper;

import com.atguigu.springboot.bean.Mtfd;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MtfdMapper extends BaseMapper<Mtfd> {
}
